import { useState, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Camera, 
  Upload, 
  X, 
  Check, 
  Clock, 
  AlertCircle, 
  Image as ImageIcon,
  Trash2,
  CheckCircle,
  Shield
} from "lucide-react";

interface PhotoUploadProps {
  userId: string;
  onPhotoUploaded?: (imageUrl: string) => void;
}

export function PhotoUpload({ userId, onPhotoUploaded }: PhotoUploadProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const { data: verificationStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/verification-status"],
    refetchInterval: 30000, // Check every 30 seconds
  });

  const { data: guidelines } = useQuery({
    queryKey: ["/api/verification-guidelines"],
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('photo', file);
      
      return await apiRequest('POST', '/api/upload-photo', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Photo téléchargée",
        description: "Votre photo est en cours de vérification",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/verification-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setPreviewUrl(null);
      onPhotoUploaded?.(data.imageUrl);
    },
    onError: (error: any) => {
      toast({
        title: "Erreur de téléchargement",
        description: error.message || "Impossible de télécharger la photo",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('DELETE', '/api/profile-photo');
    },
    onSuccess: () => {
      toast({
        title: "Photo supprimée",
        description: "Votre photo a été supprimée avec succès",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/verification-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de supprimer la photo",
        variant: "destructive",
      });
    },
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Type de fichier invalide",
        description: "Veuillez sélectionner une image",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "Fichier trop volumineux",
        description: "La taille maximale est de 10MB",
        variant: "destructive",
      });
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = () => {
    if (!previewUrl) return;
    
    // Get file from input
    const file = fileInputRef.current?.files?.[0];
    if (file) {
      uploadMutation.mutate(file);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'rejected':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return <ImageIcon className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="text-yellow-700 border-yellow-300">En attente</Badge>;
      case 'approved':
        return <Badge variant="outline" className="text-green-700 border-green-300">Approuvée</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="text-red-700 border-red-300">Rejetée</Badge>;
      default:
        return <Badge variant="outline">Aucune photo</Badge>;
    }
  };

  const getStatusMessage = (status: string) => {
    switch (status) {
      case 'pending':
        return "Votre photo est en cours de vérification. Cela peut prendre jusqu'à 24 heures.";
      case 'approved':
        return "Votre photo a été approuvée et vérifiée.";
      case 'rejected':
        return "Votre photo a été rejetée. Veuillez télécharger une nouvelle photo qui respecte nos directives.";
      default:
        return "Ajoutez une photo de profil pour commencer.";
    }
  };

  if (statusLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            {getStatusIcon(verificationStatus?.status)}
            <span>Photo de profil</span>
            {verificationStatus?.isVerified && (
              <Shield className="w-4 h-4 text-blue-500" />
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            {getStatusBadge(verificationStatus?.status)}
            {verificationStatus?.status !== 'no_profile' && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteMutation.mutate()}
                disabled={deleteMutation.isPending}
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="w-4 h-4 mr-1" />
                Supprimer
              </Button>
            )}
          </div>
          
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {getStatusMessage(verificationStatus?.status)}
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Upload Area */}
      {verificationStatus?.canUpload && (
        <Card>
          <CardHeader>
            <CardTitle>Télécharger une photo</CardTitle>
          </CardHeader>
          <CardContent>
            {previewUrl ? (
              <div className="space-y-4">
                <div className="relative">
                  <img 
                    src={previewUrl} 
                    alt="Aperçu" 
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setPreviewUrl(null)}
                    className="absolute top-2 right-2 bg-black/50 text-white hover:bg-black/70"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={handleUpload}
                    disabled={uploadMutation.isPending}
                    className="flex-1"
                  >
                    {uploadMutation.isPending ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    ) : (
                      <Check className="w-4 h-4 mr-2" />
                    )}
                    Confirmer
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setPreviewUrl(null)}
                    disabled={uploadMutation.isPending}
                  >
                    Annuler
                  </Button>
                </div>
              </div>
            ) : (
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive
                    ? 'border-pink-500 bg-pink-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <Camera className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">
                  Glissez-déposez une photo ici ou cliquez pour sélectionner
                </p>
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="mb-4"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Choisir une photo
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileInput}
                  className="hidden"
                />
                <p className="text-sm text-gray-500">
                  JPEG, PNG ou WebP • Max 10MB
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Guidelines */}
      {guidelines && (
        <Card>
          <CardHeader>
            <CardTitle>Directives pour les photos</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {guidelines.guidelines.map((guideline: string, index: number) => (
                <li key={index} className="flex items-start space-x-2">
                  <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{guideline}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}