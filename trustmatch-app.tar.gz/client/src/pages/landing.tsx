import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Icons } from "@/lib/icons";

export default function Landing() {
  const handleLogin = () => {
    const returnTo = encodeURIComponent(window.location.pathname);
    window.location.href = `/api/login?returnTo=${returnTo}`;
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="w-10 h-10 gradient-primary rounded-full flex items-center justify-center">
              <Icons.Heart className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">TrustMatch</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="max-w-md w-full space-y-8">
          {/* Hero Section */}
          <div className="text-center space-y-4">
            <div className="gradient-trust rounded-2xl p-6 text-white">
              <h2 className="text-3xl font-bold mb-2">Rencontres Basées sur l'Honnêteté</h2>
              <p className="text-lg opacity-90">
                Découvrez des profils évalués par notre communauté pour leur transparence et authenticité
              </p>
            </div>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 gap-4">
            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Icons.Star className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Système d'Évaluation</h3>
                    <p className="text-sm text-gray-600">Les femmes évaluent l'honnêteté des hommes</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-green-500">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <Icons.Shield className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Profils Vérifiés</h3>
                    <p className="text-sm text-gray-600">Authenticity garantie par la communauté</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-pink-500">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center">
                    <Icons.Users className="w-5 h-5 text-pink-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Communauté Bienveillante</h3>
                    <p className="text-sm text-gray-600">Rencontres basées sur la confiance mutuelle</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* CTA */}
          <div className="space-y-4">
            <Button 
              onClick={handleLogin}
              className="w-full gradient-primary text-white py-6 text-lg font-semibold rounded-xl hover:opacity-90 transition-opacity"
            >
              Commencer mon aventure
            </Button>
            <p className="text-center text-sm text-gray-600">
              Rejoignez notre communauté basée sur l'honnêteté et la transparence
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
