import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertProfileSchema, insertRatingSchema, insertSwipeSchema, insertChallengeResponseSchema, insertMatchConversationSchema } from "@shared/schema";
import { upload, processProfileImage, verifyProfileImage, deleteProfileImage } from "./upload";
import { submitForVerification, getVerificationStatus, getVerificationGuidelines } from "./imageVerification";
import { seedAchievements, checkUserAchievements } from "./achievementService";
import { z } from "zod";
import Stripe from "stripe";
import express from "express";
import path from "path";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-09-30.acacia",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Static file serving for uploads
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
  
  // Initialize achievements
  await seedAchievements();
  
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const profile = await storage.getProfile(userId);
      
      // Check for new achievements
      await checkUserAchievements(userId);
      
      res.json({
        ...user,
        profile,
      });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Profile routes
  app.post('/api/profiles', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = insertProfileSchema.parse({
        ...req.body,
        userId,
      });

      const existingProfile = await storage.getProfile(userId);
      if (existingProfile) {
        const updatedProfile = await storage.updateProfile(userId, profileData);
        
        // Check for new achievements after profile update
        await checkUserAchievements(userId);
        
        res.json(updatedProfile);
      } else {
        const newProfile = await storage.createProfile(profileData);
        
        // Check for new achievements after profile update
        await checkUserAchievements(userId);
        
        res.json(newProfile);
      }
    } catch (error) {
      console.error("Error creating/updating profile:", error);
      res.status(400).json({ message: "Failed to create/update profile" });
    }
  });

  app.get('/api/profiles/:userId', isAuthenticated, async (req, res) => {
    try {
      const { userId } = req.params;
      const profile = await storage.getProfileWithDetails(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  // Discovery routes
  app.get('/api/discover', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const profiles = await storage.getDiscoverableProfiles(userId, limit);
      res.json(profiles);
    } catch (error) {
      console.error("Error fetching discoverable profiles:", error);
      res.status(500).json({ message: "Failed to fetch profiles" });
    }
  });

  // Rating routes
  app.post('/api/ratings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userProfile = await storage.getProfile(userId);
      
      if (!userProfile || userProfile.gender !== 'female') {
        return res.status(403).json({ message: "Only women can rate profiles" });
      }

      const ratingData = insertRatingSchema.parse({
        ...req.body,
        raterId: userId,
      });

      const rating = await storage.createRating(ratingData);
      res.json(rating);
    } catch (error) {
      console.error("Error creating rating:", error);
      res.status(400).json({ message: "Failed to create rating" });
    }
  });

  app.get('/api/ratings/:userId', isAuthenticated, async (req, res) => {
    try {
      const { userId } = req.params;
      const ratings = await storage.getRatingsForUser(userId);
      res.json(ratings);
    } catch (error) {
      console.error("Error fetching ratings:", error);
      res.status(500).json({ message: "Failed to fetch ratings" });
    }
  });

  app.get('/api/my-ratings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const ratings = await storage.getUserRatings(userId);
      res.json(ratings);
    } catch (error) {
      console.error("Error fetching user ratings:", error);
      res.status(500).json({ message: "Failed to fetch user ratings" });
    }
  });

  // Swipe routes
  app.post('/api/swipes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const swipeData = insertSwipeSchema.parse({
        ...req.body,
        swiperId: userId,
      });

      // Check if already swiped
      const hasSwipped = await storage.hasUserSwiped(userId, swipeData.swipedUserId);
      if (hasSwipped) {
        return res.status(400).json({ message: "Already swiped on this user" });
      }

      const swipe = await storage.createSwipe(swipeData);

      // Check for mutual likes to create match
      if (swipeData.liked) {
        const reciprocalSwipes = await storage.getSwipesBetweenUsers(swipeData.swipedUserId, userId);
        const mutualLike = reciprocalSwipes.find(s => s.liked);
        
        if (mutualLike) {
          await storage.createMatch(userId, swipeData.swipedUserId);
          res.json({ ...swipe, matched: true });
        } else {
          res.json({ ...swipe, matched: false });
        }
      } else {
        res.json({ ...swipe, matched: false });
      }
    } catch (error) {
      console.error("Error creating swipe:", error);
      res.status(400).json({ message: "Failed to create swipe" });
    }
  });

  // Match routes
  app.get('/api/matches', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const matches = await storage.getUserMatches(userId);
      res.json(matches);
    } catch (error) {
      console.error("Error fetching matches:", error);
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });

  // Photo upload routes
  app.post('/api/upload-photo', isAuthenticated, upload.single('photo'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      if (!req.file) {
        return res.status(400).json({ message: "Aucun fichier téléchargé" });
      }

      // Check if user can upload (not currently pending verification)
      const verificationStatus = await getVerificationStatus(userId);
      if (!verificationStatus.canUpload) {
        return res.status(400).json({ 
          message: "Vous avez déjà une photo en cours de vérification" 
        });
      }

      // Verify image quality and content
      const verification = await verifyProfileImage(req.file.buffer);
      if (!verification.isValid) {
        return res.status(400).json({ 
          message: "Photo non valide",
          issues: verification.issues 
        });
      }

      // Process and save image
      const processedImage = await processProfileImage(req.file.buffer, userId);
      
      // Submit for verification
      await submitForVerification(userId, processedImage.url);
      
      res.json({
        message: "Photo téléchargée avec succès",
        imageUrl: processedImage.url,
        thumbnailUrl: processedImage.thumbnailUrl,
        verification,
      });
    } catch (error: any) {
      console.error("Error uploading photo:", error);
      res.status(500).json({ message: error.message || "Erreur lors du téléchargement" });
    }
  });

  app.get('/api/verification-status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const status = await getVerificationStatus(userId);
      res.json(status);
    } catch (error) {
      console.error("Error fetching verification status:", error);
      res.status(500).json({ message: "Failed to fetch verification status" });
    }
  });

  app.get('/api/verification-guidelines', (req, res) => {
    res.json({
      guidelines: getVerificationGuidelines(),
    });
  });

  app.delete('/api/profile-photo', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getProfile(userId);
      
      if (!profile?.profileImageUrl) {
        return res.status(404).json({ message: "Aucune photo à supprimer" });
      }

      // Delete image files
      const filename = profile.profileImageUrl.split('/').pop();
      if (filename) {
        await deleteProfileImage(filename);
      }

      // Update profile
      await storage.updateProfile(userId, {
        profileImageUrl: null,
        profileImageThumbnailUrl: null,
        isProfileImageVerified: false,
        profileImageVerificationStatus: "pending",
      });

      res.json({ message: "Photo supprimée avec succès" });
    } catch (error) {
      console.error("Error deleting photo:", error);
      res.status(500).json({ message: "Erreur lors de la suppression" });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", isAuthenticated, async (req: any, res) => {
    try {
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "eur",
        automatic_payment_methods: {
          enabled: true,
        },
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Subscription route
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        
        if (subscription.status === 'active') {
          return res.json({
            subscriptionId: subscription.id,
            status: subscription.status,
            message: "Already subscribed"
          });
        }
      }
      
      if (!user.email) {
        return res.status(400).json({ message: 'No user email on file' });
      }

      let customerId = user.stripeCustomerId;
      
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: `${user.firstName} ${user.lastName}`,
        });
        customerId = customer.id;
      }

      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{
          price_data: {
            currency: 'eur',
            product_data: {
              name: 'TrustMatch Premium',
              description: 'Accès aux fonctionnalités premium de TrustMatch',
            },
            unit_amount: 999, // 9.99 EUR
            recurring: {
              interval: 'month',
            },
          },
        }],
        payment_behavior: 'default_incomplete',
        payment_settings: {
          save_default_payment_method: 'on_subscription',
        },
        expand: ['latest_invoice.payment_intent'],
      });

      await storage.updateUserStripeInfo(userId, customerId, subscription.id);

      const invoice = subscription.latest_invoice as Stripe.Invoice;
      const paymentIntent = invoice.payment_intent as Stripe.PaymentIntent;
  
      res.json({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: "Error creating subscription: " + error.message });
    }
  });

  // Check subscription status
  app.get('/api/subscription-status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !user.stripeSubscriptionId) {
        return res.json({ status: 'free', subscribed: false });
      }

      const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
      
      res.json({
        status: subscription.status,
        subscribed: subscription.status === 'active',
        currentPeriodEnd: subscription.current_period_end,
      });
    } catch (error: any) {
      console.error("Error checking subscription status:", error);
      res.status(500).json({ message: "Error checking subscription status" });
    }
  });

  // Mini-challenge routes
  app.get('/api/mini-challenges', isAuthenticated, async (req, res) => {
    try {
      const { category } = req.query;
      const challenges = await storage.getMiniChallenges(category as string);
      res.json(challenges);
    } catch (error) {
      console.error("Error fetching mini-challenges:", error);
      res.status(500).json({ message: "Failed to fetch mini-challenges" });
    }
  });

  app.get('/api/random-challenge', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userResponses = await storage.getUserChallengeResponses(userId);
      const excludeAnswered = userResponses.map(r => r.challengeId.toString());
      
      const challenge = await storage.getRandomChallenge(excludeAnswered);
      if (!challenge) {
        return res.status(404).json({ message: "Aucun défi disponible" });
      }
      
      res.json(challenge);
    } catch (error) {
      console.error("Error fetching random challenge:", error);
      res.status(500).json({ message: "Failed to fetch random challenge" });
    }
  });

  app.post('/api/challenge-responses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const responseData = insertChallengeResponseSchema.parse({
        ...req.body,
        userId,
      });

      const response = await storage.createChallengeResponse(responseData);
      res.json(response);
    } catch (error) {
      console.error("Error creating challenge response:", error);
      res.status(400).json({ message: "Failed to create challenge response" });
    }
  });

  app.get('/api/my-challenge-responses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const responses = await storage.getUserChallengeResponses(userId);
      res.json(responses);
    } catch (error) {
      console.error("Error fetching user challenge responses:", error);
      res.status(500).json({ message: "Failed to fetch user challenge responses" });
    }
  });

  app.post('/api/match-conversations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversationData = insertMatchConversationSchema.parse({
        ...req.body,
        initiatorId: userId,
      });

      const conversation = await storage.createMatchConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      console.error("Error creating match conversation:", error);
      res.status(400).json({ message: "Failed to create match conversation" });
    }
  });

  app.get('/api/match-conversations/:matchId', isAuthenticated, async (req, res) => {
    try {
      const { matchId } = req.params;
      const conversations = await storage.getMatchConversations(matchId);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching match conversations:", error);
      res.status(500).json({ message: "Failed to fetch match conversations" });
    }
  });

  // Achievement routes
  app.get('/api/achievements', isAuthenticated, async (req, res) => {
    try {
      const achievements = await storage.getAchievements();
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  app.get('/api/my-achievements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userAchievements = await storage.getUserAchievements(userId);
      res.json(userAchievements);
    } catch (error) {
      console.error("Error fetching user achievements:", error);
      res.status(500).json({ message: "Failed to fetch user achievements" });
    }
  });

  app.get('/api/profile-completion', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const completion = await storage.getProfileCompletionScore(userId);
      res.json(completion);
    } catch (error) {
      console.error("Error fetching profile completion:", error);
      res.status(500).json({ message: "Failed to fetch profile completion" });
    }
  });

  app.post('/api/check-achievements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.checkAndUpdateAchievements(userId);
      res.json({ message: "Achievements checked successfully" });
    } catch (error) {
      console.error("Error checking achievements:", error);
      res.status(500).json({ message: "Failed to check achievements" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
