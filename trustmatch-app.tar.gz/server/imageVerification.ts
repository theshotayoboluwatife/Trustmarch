import { storage } from "./storage";
import { db } from "./db";
import { profiles } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface VerificationResult {
  approved: boolean;
  reason?: string;
  confidence: number;
}

export async function submitForVerification(userId: string, imageUrl: string): Promise<void> {
  await db
    .update(profiles)
    .set({
      profileImageUrl: imageUrl,
      profileImageVerificationStatus: "pending",
      isProfileImageVerified: false,
      updatedAt: new Date(),
    })
    .where(eq(profiles.userId, userId));
}

export async function approveImage(userId: string, adminId: string): Promise<void> {
  await db
    .update(profiles)
    .set({
      profileImageVerificationStatus: "approved",
      isProfileImageVerified: true,
      updatedAt: new Date(),
    })
    .where(eq(profiles.userId, userId));
  
  // In a real app, you'd log this action
  console.log(`Image approved for user ${userId} by admin ${adminId}`);
}

export async function rejectImage(userId: string, adminId: string, reason: string): Promise<void> {
  await db
    .update(profiles)
    .set({
      profileImageVerificationStatus: "rejected",
      isProfileImageVerified: false,
      updatedAt: new Date(),
    })
    .where(eq(profiles.userId, userId));
  
  // In a real app, you'd log this action and potentially notify the user
  console.log(`Image rejected for user ${userId} by admin ${adminId}. Reason: ${reason}`);
}

export async function getPendingVerifications(): Promise<any[]> {
  const pendingProfiles = await db
    .select({
      userId: profiles.userId,
      profileImageUrl: profiles.profileImageUrl,
      profileImageThumbnailUrl: profiles.profileImageThumbnailUrl,
      createdAt: profiles.createdAt,
    })
    .from(profiles)
    .where(eq(profiles.profileImageVerificationStatus, "pending"));
  
  return pendingProfiles;
}

export async function getVerificationStatus(userId: string): Promise<{
  status: string;
  isVerified: boolean;
  canUpload: boolean;
}> {
  const profile = await storage.getProfile(userId);
  
  if (!profile) {
    return {
      status: "no_profile",
      isVerified: false,
      canUpload: true,
    };
  }
  
  const status = profile.profileImageVerificationStatus || "pending";
  const isVerified = profile.isProfileImageVerified || false;
  const canUpload = status !== "pending"; // Can upload if not currently pending
  
  return {
    status,
    isVerified,
    canUpload,
  };
}

export function getVerificationStatusMessage(status: string): string {
  switch (status) {
    case "pending":
      return "Votre photo est en cours de vérification. Cela peut prendre jusqu'à 24 heures.";
    case "approved":
      return "Votre photo a été approuvée et vérifiée.";
    case "rejected":
      return "Votre photo a été rejetée. Veuillez télécharger une nouvelle photo qui respecte nos directives.";
    default:
      return "Ajoutez une photo de profil pour commencer.";
  }
}

export function getVerificationGuidelines(): string[] {
  return [
    "Utilisez une photo récente de vous",
    "Votre visage doit être clairement visible",
    "Pas de lunettes de soleil ou de masque",
    "Pas de photos de groupe",
    "Pas de photos d'animaux ou d'objets",
    "Pas de contenu inapproprié",
    "Photos de bonne qualité uniquement"
  ];
}